import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export default function Home() {
  const { scrollY } = useScroll();
  const rotate = useTransform(scrollY, [0, 500], [0, 360]);

  return (
    <main className="bg-black text-white font-sans rtl">
      <header className="fixed top-0 left-0 w-full p-4 z-50 flex items-center justify-between bg-black/80 backdrop-blur">
        <motion.img
          src="/logo.png"
          alt="محطة المستقبل"
          className="w-16 h-16"
          style={{ rotate }}
        />
        <nav className="text-lg space-x-4 space-x-reverse">
          <a href="#services">خدماتنا</a>
          <a href="#about">من نحن</a>
          <a href="#portfolio">أعمالنا</a>
          <a href="#clients">عملاؤنا</a>
          <a href="#contact">تواصل معنا</a>
        </nav>
      </header>

      <section className="h-screen flex items-center justify-center text-center px-4">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-4xl md:text-6xl font-bold text-orange-500"
          >
            محطة المستقبل
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="text-xl md:text-2xl mt-4"
          >
            بوّابة انتشار نشاطك التجاري
          </motion.p>
          <motion.a
            href="#portfolio"
            className="inline-block mt-8 px-6 py-3 bg-orange-500 text-black font-bold rounded-full"
            whileHover={{ scale: 1.05 }}
          >
            شوف أعمالنا
          </motion.a>
        </div>
      </section>

      <section id="services" className="py-20 px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-orange-500 mb-8">خدماتنا</h2>
        <div className="space-y-6 text-lg">
          <p>الإعلانات الطرقية باحترافية عالية</p>
          <p>الطباعة الرقمية الحديثة</p>
          <p>طباعة الفلكس على أعلى مستوى وبأفضل جودة</p>
        </div>
      </section>

      <section id="portfolio" className="py-20 px-6 text-center bg-gray-800">
        <h2 className="text-3xl md:text-4xl font-bold text-orange-500 mb-8">أعمالنا</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <img src="/work/photo1.jpg" alt="عمل 1" className="w-full rounded shadow" />
          <img src="/work/photo2.jpg" alt="عمل 2" className="w-full rounded shadow" />
          <img src="/work/photo3.jpg" alt="عمل 3" className="w-full rounded shadow" />
          <img src="/work/photo4.jpg" alt="عمل 4" className="w-full rounded shadow" />
          <img src="/work/photo5.jpg" alt="عمل 5" className="w-full rounded shadow" />
          <img src="/work/photo6.jpg" alt="عمل 6" className="w-full rounded shadow" />
          <img src="/work/photo7.jpg" alt="عمل 7" className="w-full rounded shadow" />
          <img src="/work/photo8.jpg" alt="عمل 8" className="w-full rounded shadow" />
          <img src="/work/photo9.jpg" alt="عمل 9" className="w-full rounded shadow" />
        </div>
      </section>

      <section id="clients" className="py-20 px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-orange-500 mb-8">عملاؤنا</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 items-center">
          <img src="/clients/emlaq.png" alt="العملاق" className="w-full h-24 object-contain" />
          <img src="/clients/rafidain.png" alt="ملتقى الرافدين" className="w-full h-24 object-contain" />
          <img src="/clients/donga.png" alt="دونجا" className="w-full h-24 object-contain" />
          <img src="/clients/garden.png" alt="جاردن سيتي" className="w-full h-24 object-contain" />
          <img src="/clients/o2.png" alt="O2" className="w-full h-24 object-contain" />
          <img src="/clients/puck.png" alt="بوك" className="w-full h-24 object-contain" />
          <img src="/clients/mg.png" alt="MG" className="w-full h-24 object-contain" />
          <img src="/clients/apple.png" alt="Apple" className="w-full h-24 object-contain" />
          <img src="/clients/lurpak.png" alt="Lurpak" className="w-full h-24 object-contain" />
          <img src="/clients/touf.png" alt="Touf" className="w-full h-24 object-contain" />
        </div>
      </section>

      <section id="contact" className="py-20 px-6 bg-gray-900 text-white">
        <h2 className="text-3xl md:text-4xl font-bold text-orange-500 mb-8 text-center">تواصل ويانا</h2>
        <form className="max-w-xl mx-auto space-y-4" action="mailto:info@fs-ads.com" method="POST" encType="text/plain">
          <input type="text" name="name" placeholder="الاسم" className="w-full p-3 rounded bg-black border border-orange-500" required />
          <input type="email" name="email" placeholder="البريد الإلكتروني" className="w-full p-3 rounded bg-black border border-orange-500" required />
          <textarea name="message" placeholder="رسالتك" className="w-full p-3 rounded bg-black border border-orange-500" rows="5" required></textarea>
          <button type="submit" className="w-full py-3 bg-orange-500 text-black font-bold rounded hover:bg-orange-600">إرسال</button>
        </form>

        <div className="text-center mt-10 text-lg">
          <p>📞 07734060808</p>
          <p>📞 07844100800</p>
          <p>📞 07844100600</p>
        </div>

        <div className="flex justify-center gap-6 mt-6 text-2xl">
          <a href="https://www.facebook.com/futurestationads" target="_blank" rel="noopener noreferrer">فيسبوك</a>
          <a href="https://www.instagram.com/futurestationads" target="_blank" rel="noopener noreferrer">إنستغرام</a>
          <a href="https://www.linkedin.com/company/futurestationads" target="_blank" rel="noopener noreferrer">لينكدإن</a>
        </div>
      </section>
    </main>
  );
}
